<form role="search" method="GET" action="" class="formatted-form">
	<div class="field-wrap">
		<input type="text" value="<?php the_search_query(); ?>" name="s" placeholder="<?php _e('Search', 'lovestory'); ?>" class="form-submit" />
	</div>	
</form>