<?php get_header(); ?>
<div class="woocommerce" id="container">
	<div id="content">
		<?php woocommerce_content(); ?>
	</div>
</div>
<!-- /woocommerce -->
<?php get_footer(); ?>